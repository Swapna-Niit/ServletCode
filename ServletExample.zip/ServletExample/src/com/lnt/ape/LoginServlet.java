package com.lnt.ape;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	Connection con = null;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		DBForServlet bfs = new DBForServlet();
		try {
		con = bfs.dbConnect();
		
		PrintWriter pw = response.getWriter();
		
		PreparedStatement pstmt;
		
			pstmt = con.prepareStatement
			("select * from loguser where uname = ? and pwd = ?");
		
		
		String suser = request.getParameter("username");
		String spass = request.getParameter("password");
	
		pstmt.setString(1, suser);
		pstmt.setString(2, spass);
		
		ResultSet rs = pstmt.executeQuery();
		
		if(rs.next())
		{
			pw.print("user logged in successful");
			response.sendRedirect("success.jsp");
		}
		else
		{
			pw.print("Credentials are not matching");
		}
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
