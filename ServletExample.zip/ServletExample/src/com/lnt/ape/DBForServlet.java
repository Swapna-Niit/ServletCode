package com.lnt.ape;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class DBForServlet {
	
	Connection con = null;
	String url = "jdbc:h2:tcp://localhost/~/test";
	String user = "sa";
	String password = "root";
	
	public Connection dbConnect() throws ClassNotFoundException, SQLException
	{
	
		Class.forName("org.h2.Driver");
		con = DriverManager.getConnection(url, user, password);
		
		//return con;
		
	
	return con;

		
	}

}
